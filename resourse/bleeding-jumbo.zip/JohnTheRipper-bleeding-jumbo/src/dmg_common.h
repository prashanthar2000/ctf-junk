/*
 * This software is Copyright (c) 2017, magnum
 * and it is hereby released to the general public under the following terms:
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted.
 */

extern struct fmt_tests dmg_tests[];
