package androidx.lifecycle;

import a.j.c;
import a.j.e;
import a.j.f;
import a.j.h;
import a.j.l;

public class SingleGeneratedAdapterObserver implements f {

    /* renamed from: a  reason: collision with root package name */
    public final c f527a;

    public SingleGeneratedAdapterObserver(c cVar) {
        this.f527a = cVar;
    }

    public void a(h hVar, e.a aVar) {
        this.f527a.a(hVar, aVar, false, (l) null);
        this.f527a.a(hVar, aVar, true, (l) null);
    }
}
