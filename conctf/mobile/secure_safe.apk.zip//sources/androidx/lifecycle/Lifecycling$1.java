package androidx.lifecycle;

import a.j.d;
import a.j.e;
import a.j.h;

public final class Lifecycling$1 implements d {
    public void a(h hVar, e.a aVar) {
        throw null;
    }
}
