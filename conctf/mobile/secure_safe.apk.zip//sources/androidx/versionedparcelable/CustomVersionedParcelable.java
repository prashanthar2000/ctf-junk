package androidx.versionedparcelable;

import a.n.c;

public abstract class CustomVersionedParcelable implements c {
}
