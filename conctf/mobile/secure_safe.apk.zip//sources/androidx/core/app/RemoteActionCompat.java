package androidx.core.app;

import a.n.c;
import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;

public final class RemoteActionCompat implements c {

    /* renamed from: a  reason: collision with root package name */
    public IconCompat f507a;

    /* renamed from: b  reason: collision with root package name */
    public CharSequence f508b;
    public CharSequence c;
    public PendingIntent d;
    public boolean e;
    public boolean f;
}
