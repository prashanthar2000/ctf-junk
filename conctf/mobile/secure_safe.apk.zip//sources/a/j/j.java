package a.j;

@Deprecated
public interface j extends h {
    i a();
}
