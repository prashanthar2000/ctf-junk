package a.j;

import a.j.e;

public interface c {
    void a(h hVar, e.a aVar, boolean z, l lVar);
}
