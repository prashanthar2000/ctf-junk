package a.j;

public interface g {
}
