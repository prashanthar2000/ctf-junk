package a.j;

public interface b extends g {
    void a(h hVar);

    void b(h hVar);

    void c(h hVar);

    void d(h hVar);

    void e(h hVar);

    void f(h hVar);
}
