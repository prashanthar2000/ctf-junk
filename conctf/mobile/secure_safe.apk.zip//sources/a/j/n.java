package a.j;

public interface n<T> {
    void a(T t);
}
