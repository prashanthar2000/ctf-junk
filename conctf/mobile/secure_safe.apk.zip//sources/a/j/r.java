package a.j;

public interface r {
    <T extends q> T a(Class<T> cls);
}
