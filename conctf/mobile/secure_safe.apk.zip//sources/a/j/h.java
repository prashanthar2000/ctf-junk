package a.j;

public interface h {
    e a();
}
