package a.j;

import java.util.HashMap;

public class t {

    /* renamed from: a  reason: collision with root package name */
    public final HashMap<String, q> f417a = new HashMap<>();

    public final void a() {
        for (q a2 : this.f417a.values()) {
            a2.a();
        }
        this.f417a.clear();
    }
}
