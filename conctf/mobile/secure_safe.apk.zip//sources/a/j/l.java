package a.j;

import java.util.HashMap;

public class l {
    public l() {
        new HashMap();
    }
}
