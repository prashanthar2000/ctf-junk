package a.j;

@Deprecated
public interface d extends f {
}
