package a.j;

public interface u {
    t d();
}
