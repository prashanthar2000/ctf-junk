package a.j;

import a.j.e;

public interface f extends g {
    void a(h hVar, e.a aVar);
}
