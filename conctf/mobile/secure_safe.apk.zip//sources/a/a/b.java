package a.a;

import java.util.concurrent.CopyOnWriteArrayList;

public abstract class b {

    /* renamed from: a  reason: collision with root package name */
    public boolean f0a;

    /* renamed from: b  reason: collision with root package name */
    public CopyOnWriteArrayList<a> f1b = new CopyOnWriteArrayList<>();

    public b(boolean z) {
        this.f0a = z;
    }
}
