package a.a;

public interface a {
    void cancel();
}
