package a.a;

import a.j.h;
import androidx.activity.OnBackPressedDispatcher;

public interface c extends h {
    OnBackPressedDispatcher b();
}
