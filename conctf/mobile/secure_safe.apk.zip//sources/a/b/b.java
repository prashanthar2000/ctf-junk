package a.b;

public final class b {
    public static final int abc_action_bar_embed_tabs = 2130903040;
    public static final int abc_allow_stacked_button_bar = 2130903041;
    public static final int abc_config_actionMenuItemAllCaps = 2130903042;
}
