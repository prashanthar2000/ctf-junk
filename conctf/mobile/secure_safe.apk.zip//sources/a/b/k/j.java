package a.b.k;

import a.b.p.g0;

public class j implements g0 {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ h f22a;
}
