package a.b.k;

import a.b.o.a;

public interface f {
    a a(a.C0004a aVar);

    void a(a aVar);

    void b(a aVar);
}
