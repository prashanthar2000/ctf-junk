package a.b.k;

public class i implements a.f.k.i {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ h f21a;

    public i(h hVar) {
        this.f21a = hVar;
    }
}
