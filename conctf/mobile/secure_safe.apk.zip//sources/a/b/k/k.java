package a.b.k;

import androidx.appcompat.widget.ContentFrameLayout;

public class k implements ContentFrameLayout.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ h f23a;

    public k(h hVar) {
        this.f23a = hVar;
    }
}
