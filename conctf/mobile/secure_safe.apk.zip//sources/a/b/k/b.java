package a.b.k;

import android.view.View;
import androidx.core.widget.NestedScrollView;

public class b implements NestedScrollView.b {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ View f3a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ View f4b;
}
