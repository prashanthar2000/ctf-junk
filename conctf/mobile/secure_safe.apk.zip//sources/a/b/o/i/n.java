package a.b.o.i;

public interface n {

    public interface a {
        void a(i iVar, int i);

        boolean c();

        i getItemData();
    }

    void a(g gVar);
}
