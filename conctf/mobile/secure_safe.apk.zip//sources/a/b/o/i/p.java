package a.b.o.i;

import android.widget.ListView;

public interface p {
    boolean a();

    ListView d();

    void dismiss();

    void e();
}
