package a.b.o;

import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

public abstract class a {

    /* renamed from: b  reason: collision with root package name */
    public Object f56b;
    public boolean c;

    /* renamed from: a.b.o.a$a  reason: collision with other inner class name */
    public interface C0004a {
        void a(a aVar);

        boolean a(a aVar, Menu menu);

        boolean a(a aVar, MenuItem menuItem);

        boolean b(a aVar, Menu menu);
    }

    public abstract void a();

    public abstract void a(int i);

    public abstract void a(View view);

    public abstract void a(CharSequence charSequence);

    public abstract void a(boolean z);

    public abstract View b();

    public abstract void b(int i);

    public abstract void b(CharSequence charSequence);

    public abstract Menu c();

    public abstract MenuInflater d();

    public abstract CharSequence e();

    public abstract CharSequence f();

    public abstract void g();

    public abstract boolean h();
}
