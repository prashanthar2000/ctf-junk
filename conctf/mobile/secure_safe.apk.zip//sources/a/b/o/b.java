package a.b.o;

public interface b {
    void a();

    void b();
}
