package a.b.o.i;

import android.content.Context;

public interface m {

    public interface a {
        void a(g gVar, boolean z);

        boolean a(g gVar);
    }

    void a(g gVar, boolean z);

    void a(a aVar);

    void a(Context context, g gVar);

    void a(boolean z);

    boolean a(g gVar, i iVar);

    boolean a(r rVar);

    boolean b();

    boolean b(g gVar, i iVar);
}
