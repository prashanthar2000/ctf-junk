package a.b.p;

import android.content.res.Resources;

public class o0 extends Resources {
}
