package a.b.p;

import a.b.o.i.m;
import android.view.Menu;
import android.view.Window;

public interface c0 {
    void a(int i);

    void a(Menu menu, m.a aVar);

    boolean a();

    boolean b();

    void c();

    boolean d();

    boolean e();

    boolean f();

    void g();

    void setWindowCallback(Window.Callback callback);

    void setWindowTitle(CharSequence charSequence);
}
