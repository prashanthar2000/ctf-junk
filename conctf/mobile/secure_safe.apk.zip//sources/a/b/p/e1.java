package a.b.p;

public interface e1 {
    CharSequence a();
}
