package a.b.p;

import a.b.o.i.g;
import android.view.MenuItem;

public interface l0 {
    void a(g gVar, MenuItem menuItem);

    void b(g gVar, MenuItem menuItem);
}
