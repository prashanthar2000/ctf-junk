package a.b.p;

public interface g0 {
}
