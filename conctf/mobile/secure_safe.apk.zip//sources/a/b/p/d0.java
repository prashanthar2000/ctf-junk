package a.b.p;

import a.b.o.i.m;
import a.f.k.p;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.Menu;
import android.view.ViewGroup;
import android.view.Window;

public interface d0 {
    p a(int i, long j);

    void a(int i);

    void a(q0 q0Var);

    void a(Menu menu, m.a aVar);

    void a(boolean z);

    boolean a();

    void b(int i);

    void b(boolean z);

    boolean b();

    void c();

    void c(int i);

    void collapseActionView();

    boolean d();

    boolean e();

    boolean f();

    void g();

    CharSequence getTitle();

    int h();

    void i();

    boolean j();

    ViewGroup k();

    void l();

    Context m();

    int n();

    void setIcon(int i);

    void setIcon(Drawable drawable);

    void setWindowCallback(Window.Callback callback);

    void setWindowTitle(CharSequence charSequence);
}
