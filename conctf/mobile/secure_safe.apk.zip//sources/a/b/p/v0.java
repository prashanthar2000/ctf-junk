package a.b.p;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;

public class v0 {

    /* renamed from: a  reason: collision with root package name */
    public ColorStateList f173a;

    /* renamed from: b  reason: collision with root package name */
    public PorterDuff.Mode f174b;
    public boolean c;
    public boolean d;
}
