package a.b.p;

public class w0 extends o0 {
}
