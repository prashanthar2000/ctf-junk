package a.b.p;

import android.content.res.Resources;

public class c1 extends Resources {
    public static boolean a() {
        return false;
    }
}
