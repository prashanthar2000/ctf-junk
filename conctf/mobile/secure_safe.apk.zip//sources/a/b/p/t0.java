package a.b.p;

import android.content.res.Resources;
import android.widget.SpinnerAdapter;

public interface t0 extends SpinnerAdapter {
    Resources.Theme getDropDownViewTheme();

    void setDropDownViewTheme(Resources.Theme theme);
}
