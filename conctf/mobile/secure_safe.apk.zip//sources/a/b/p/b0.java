package a.b.p;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ToggleButton;

public class b0 extends ToggleButton {

    /* renamed from: b  reason: collision with root package name */
    public final y f115b;

    public b0(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 16842827);
        y yVar = new y(this);
        this.f115b = yVar;
        yVar.a(attributeSet, 16842827);
    }
}
