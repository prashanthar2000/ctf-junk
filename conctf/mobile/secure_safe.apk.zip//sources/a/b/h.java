package a.b;

public final class h {
    public static final int abc_action_bar_home_description = 2131492864;
    public static final int abc_action_bar_up_description = 2131492865;
    public static final int abc_action_menu_overflow_description = 2131492866;
    public static final int abc_action_mode_done = 2131492867;
    public static final int abc_activity_chooser_view_see_all = 2131492868;
    public static final int abc_activitychooserview_choose_application = 2131492869;
    public static final int abc_capital_off = 2131492870;
    public static final int abc_capital_on = 2131492871;
    public static final int abc_menu_alt_shortcut_label = 2131492872;
    public static final int abc_menu_ctrl_shortcut_label = 2131492873;
    public static final int abc_menu_delete_shortcut_label = 2131492874;
    public static final int abc_menu_enter_shortcut_label = 2131492875;
    public static final int abc_menu_function_shortcut_label = 2131492876;
    public static final int abc_menu_meta_shortcut_label = 2131492877;
    public static final int abc_menu_shift_shortcut_label = 2131492878;
    public static final int abc_menu_space_shortcut_label = 2131492879;
    public static final int abc_menu_sym_shortcut_label = 2131492880;
    public static final int abc_prepend_shortcut_label = 2131492881;
    public static final int abc_search_hint = 2131492882;
    public static final int abc_searchview_description_clear = 2131492883;
    public static final int abc_searchview_description_query = 2131492884;
    public static final int abc_searchview_description_search = 2131492885;
    public static final int abc_searchview_description_submit = 2131492886;
    public static final int abc_searchview_description_voice = 2131492887;
    public static final int abc_shareactionprovider_share_with = 2131492888;
    public static final int abc_shareactionprovider_share_with_application = 2131492889;
    public static final int abc_toolbar_collapse_description = 2131492890;
    public static final int search_menu_title = 2131492893;
    public static final int status_bar_notification_info_overflow = 2131492894;
}
