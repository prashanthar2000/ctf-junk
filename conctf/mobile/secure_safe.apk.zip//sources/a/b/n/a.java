package a.b.n;

public final class a {
    public static final int abc_vector_test = 2131099734;
    public static final int notification_action_background = 2131099745;
    public static final int notification_bg = 2131099746;
    public static final int notification_bg_low = 2131099747;
    public static final int notification_bg_low_normal = 2131099748;
    public static final int notification_bg_low_pressed = 2131099749;
    public static final int notification_bg_normal = 2131099750;
    public static final int notification_bg_normal_pressed = 2131099751;
    public static final int notification_icon_background = 2131099752;
    public static final int notification_template_icon_bg = 2131099753;
    public static final int notification_template_icon_low_bg = 2131099754;
    public static final int notification_tile_bg = 2131099755;
    public static final int notify_panel_notification_icon_bg = 2131099756;
}
