package a.f.k.u;

import android.os.Bundle;
import android.view.View;

public interface d {

    public static abstract class a {
        static {
            new Bundle();
        }
    }

    public static final class b extends a {
    }

    public static final class c extends a {
    }

    /* renamed from: a.f.k.u.d$d  reason: collision with other inner class name */
    public static final class C0018d extends a {
    }

    public static final class e extends a {
    }

    public static final class f extends a {
    }

    public static final class g extends a {
    }

    public static final class h extends a {
    }

    boolean a(View view, a aVar);
}
