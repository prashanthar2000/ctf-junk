package a.f.k.u;

public class c {

    /* renamed from: a  reason: collision with root package name */
    public final Object f342a;

    public c(Object obj) {
        this.f342a = obj;
    }
}
