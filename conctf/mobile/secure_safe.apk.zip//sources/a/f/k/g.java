package a.f.k;

import android.view.View;

public interface g extends f {
    void a(View view, int i, int i2, int i3, int i4, int i5, int[] iArr);
}
