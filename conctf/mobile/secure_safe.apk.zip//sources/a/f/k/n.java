package a.f.k;

import a.f.k.k;
import android.view.View;

public final class n extends k.b<Boolean> {
    public n(int i, Class cls, int i2) {
        super(i, cls, i2);
    }

    public Object a(View view) {
        return Boolean.valueOf(view.isAccessibilityHeading());
    }
}
