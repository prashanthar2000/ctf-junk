package a.f.k;

import android.view.View;

public class r implements q {
    public void b(View view) {
    }

    public void c(View view) {
    }
}
