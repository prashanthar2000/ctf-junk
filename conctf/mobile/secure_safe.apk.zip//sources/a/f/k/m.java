package a.f.k;

import a.f.k.k;
import android.view.View;

public final class m extends k.b<CharSequence> {
    public m(int i, Class cls, int i2, int i3) {
        super(i, cls, i2, i3);
    }

    public Object a(View view) {
        return view.getAccessibilityPaneTitle();
    }
}
