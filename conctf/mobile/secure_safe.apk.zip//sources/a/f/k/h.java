package a.f.k;

public class h {

    /* renamed from: a  reason: collision with root package name */
    public int f320a;

    /* renamed from: b  reason: collision with root package name */
    public int f321b;
}
