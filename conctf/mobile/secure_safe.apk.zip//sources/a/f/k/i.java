package a.f.k;

public interface i {
}
