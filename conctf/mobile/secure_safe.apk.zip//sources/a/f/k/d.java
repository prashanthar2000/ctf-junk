package a.f.k;

public interface d {
}
