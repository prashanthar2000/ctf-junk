package a.f.k;

import android.view.View;

public interface q {
    void a(View view);

    void b(View view);

    void c(View view);
}
