package a.f.l;

import android.widget.ListView;

public class c extends a {
    public final ListView s;

    public c(ListView listView) {
        super(listView);
        this.s = listView;
    }
}
