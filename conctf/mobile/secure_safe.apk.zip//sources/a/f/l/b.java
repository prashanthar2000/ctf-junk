package a.f.l;

import android.os.Build;

public interface b {

    /* renamed from: a  reason: collision with root package name */
    public static final boolean f347a = (Build.VERSION.SDK_INT >= 27);
}
