package a.f;

public final class a {
    public static final int alpha = 2130837543;
    public static final int font = 2130837634;
    public static final int fontProviderAuthority = 2130837636;
    public static final int fontProviderCerts = 2130837637;
    public static final int fontProviderFetchStrategy = 2130837638;
    public static final int fontProviderFetchTimeout = 2130837639;
    public static final int fontProviderPackage = 2130837640;
    public static final int fontProviderQuery = 2130837641;
    public static final int fontStyle = 2130837642;
    public static final int fontVariationSettings = 2130837643;
    public static final int fontWeight = 2130837644;
    public static final int ttcIndex = 2130837826;
}
