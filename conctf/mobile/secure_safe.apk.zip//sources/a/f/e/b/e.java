package a.f.e.b;

import a.f.h.a;

public final class e implements b {

    /* renamed from: a  reason: collision with root package name */
    public final a f275a;

    /* renamed from: b  reason: collision with root package name */
    public final int f276b;
    public final int c;

    public e(a aVar, int i, int i2) {
        this.f275a = aVar;
        this.c = i;
        this.f276b = i2;
    }
}
