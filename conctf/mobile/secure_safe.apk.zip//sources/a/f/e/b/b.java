package a.f.e.b;

public interface b {
}
