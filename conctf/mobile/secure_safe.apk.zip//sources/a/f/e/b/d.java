package a.f.e.b;

public final class d {

    /* renamed from: a  reason: collision with root package name */
    public final String f273a;

    /* renamed from: b  reason: collision with root package name */
    public int f274b;
    public boolean c;
    public String d;
    public int e;
    public int f;

    public d(String str, int i, boolean z, String str2, int i2, int i3) {
        this.f273a = str;
        this.f274b = i;
        this.c = z;
        this.d = str2;
        this.e = i2;
        this.f = i3;
    }
}
