package a.f.e.b;

public final class c implements b {

    /* renamed from: a  reason: collision with root package name */
    public final d[] f272a;

    public c(d[] dVarArr) {
        this.f272a = dVarArr;
    }
}
