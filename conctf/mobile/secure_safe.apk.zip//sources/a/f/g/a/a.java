package a.f.g.a;

import android.view.Menu;

public interface a extends Menu {
}
