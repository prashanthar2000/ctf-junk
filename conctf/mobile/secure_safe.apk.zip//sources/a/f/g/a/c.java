package a.f.g.a;

import android.view.SubMenu;

public interface c extends a, SubMenu {
}
