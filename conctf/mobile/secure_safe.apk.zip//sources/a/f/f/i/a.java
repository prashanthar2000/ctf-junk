package a.f.f.i;

import android.graphics.drawable.Drawable;

public interface a {
    Drawable a();

    void a(Drawable drawable);
}
