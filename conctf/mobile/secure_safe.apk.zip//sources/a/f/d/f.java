package a.f.d;

import android.content.Intent;

public interface f {
    Intent e();
}
