package a.f.d;

public abstract class e {
}
