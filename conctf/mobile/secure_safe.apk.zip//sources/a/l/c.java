package a.l;

import a.j.h;

public interface c extends h {
    a c();
}
