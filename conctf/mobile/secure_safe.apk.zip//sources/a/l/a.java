package a.l;

import android.annotation.SuppressLint;
import android.os.Bundle;

@SuppressLint({"RestrictedApi"})
public final class a {

    /* renamed from: a  reason: collision with root package name */
    public a.c.a.b.b<String, b> f421a = new a.c.a.b.b<>();

    /* renamed from: b  reason: collision with root package name */
    public Bundle f422b;
    public boolean c;
    public boolean d;

    /* renamed from: a.l.a$a  reason: collision with other inner class name */
    public interface C0024a {
        void a(c cVar);
    }

    public interface b {
        Bundle a();
    }
}
