package a.i.a;

import android.util.AndroidRuntimeException;

public final class f0 extends AndroidRuntimeException {
    public f0(String str) {
        super(str);
    }
}
