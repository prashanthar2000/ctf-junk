package a.i.a;

import a.j.e;
import androidx.fragment.app.Fragment;
import java.util.ArrayList;

public abstract class q {

    /* renamed from: a  reason: collision with root package name */
    public ArrayList<a> f384a = new ArrayList<>();

    /* renamed from: b  reason: collision with root package name */
    public int f385b;
    public int c;
    public int d;
    public int e;
    public int f;
    public int g;
    public boolean h;
    public String i;
    public int j;
    public CharSequence k;
    public int l;
    public CharSequence m;
    public ArrayList<String> n;
    public ArrayList<String> o;
    public boolean p = false;
    public ArrayList<Runnable> q;

    public static final class a {

        /* renamed from: a  reason: collision with root package name */
        public int f386a;

        /* renamed from: b  reason: collision with root package name */
        public Fragment f387b;
        public int c;
        public int d;
        public int e;
        public int f;
        public e.b g;
        public e.b h;

        public a() {
        }

        public a(int i, Fragment fragment) {
            this.f386a = i;
            this.f387b = fragment;
            e.b bVar = e.b.RESUMED;
            this.g = bVar;
            this.h = bVar;
        }
    }
}
