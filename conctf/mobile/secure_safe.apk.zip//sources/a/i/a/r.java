package a.i.a;

import android.view.View;
import java.util.ArrayList;

public final class r implements Runnable {

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ ArrayList f388b;

    public r(ArrayList arrayList) {
        this.f388b = arrayList;
    }

    public void run() {
        v.a((ArrayList<View>) this.f388b, 4);
    }
}
