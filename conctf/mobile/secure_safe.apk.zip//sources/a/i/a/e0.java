package a.i.a;

import a.j.e;
import a.j.h;
import a.j.i;

public class e0 implements h {

    /* renamed from: b  reason: collision with root package name */
    public i f360b = null;

    public e a() {
        if (this.f360b == null) {
            this.f360b = new i(this);
        }
        return this.f360b;
    }
}
