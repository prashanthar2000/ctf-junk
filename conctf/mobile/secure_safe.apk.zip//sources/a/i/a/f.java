package a.i.a;

public class f {

    /* renamed from: a  reason: collision with root package name */
    public final h<?> f361a;

    public f(h<?> hVar) {
        this.f361a = hVar;
    }

    public void a() {
        this.f361a.f.j();
    }
}
