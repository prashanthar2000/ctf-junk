package a.i.a;

import androidx.fragment.app.Fragment;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.List;

public abstract class i {
    public static final g c = new g();

    /* renamed from: b  reason: collision with root package name */
    public g f364b = null;

    public abstract List<Fragment> a();

    public abstract void a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr);

    public abstract boolean b();
}
