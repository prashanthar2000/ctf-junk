package a.i.a;

import android.view.View;

public abstract class e {
    public abstract View a(int i);

    public abstract boolean e();
}
