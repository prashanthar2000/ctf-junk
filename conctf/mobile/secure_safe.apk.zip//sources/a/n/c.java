package a.n;

public interface c {
}
