package a.e.b;

public final class g {
    public static final int bottom = 2131165249;
    public static final int end = 2131165268;
    public static final int gone = 2131165273;
    public static final int invisible = 2131165283;
    public static final int left = 2131165285;
    public static final int packed = 2131165301;
    public static final int parent = 2131165302;
    public static final int percent = 2131165304;
    public static final int right = 2131165309;
    public static final int spread = 2131165333;
    public static final int spread_inside = 2131165334;
    public static final int start = 2131165339;
    public static final int top = 2131165360;
    public static final int wrap = 2131165367;
}
