package a.e.a;

public class d extends b {
    public d(c cVar) {
        super(cVar);
    }

    public void a(g gVar) {
        super.a(gVar);
        gVar.j--;
    }
}
