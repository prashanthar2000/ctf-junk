package a.e.a.h;

public class k extends l {
    public float c = 0.0f;

    public void a(int i) {
        if (this.f249b == 0 || this.c != ((float) i)) {
            this.c = (float) i;
            if (this.f249b == 1) {
                b();
            }
            a();
        }
    }
}
