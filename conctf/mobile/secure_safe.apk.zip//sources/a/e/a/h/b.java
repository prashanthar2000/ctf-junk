package a.e.a.h;

import java.util.ArrayList;

public class b {

    /* renamed from: a  reason: collision with root package name */
    public d f235a;

    /* renamed from: b  reason: collision with root package name */
    public d f236b;
    public d c;
    public d d;
    public d e;
    public d f;
    public d g;
    public ArrayList<d> h;
    public int i;
    public int j;
    public float k = 0.0f;
    public int l;
    public boolean m = false;
    public boolean n;
    public boolean o;
    public boolean p;
    public boolean q;

    public b(d dVar, int i2, boolean z) {
        this.f235a = dVar;
        this.l = i2;
        this.m = z;
    }
}
