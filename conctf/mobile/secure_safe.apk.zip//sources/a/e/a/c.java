package a.e.a;

public class c {

    /* renamed from: a  reason: collision with root package name */
    public f<b> f226a = new f<>(256);

    /* renamed from: b  reason: collision with root package name */
    public f<g> f227b = new f<>(256);
    public g[] c = new g[32];
}
