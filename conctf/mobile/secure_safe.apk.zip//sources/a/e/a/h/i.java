package a.e.a.h;

public class i {

    /* renamed from: a  reason: collision with root package name */
    public static boolean[] f247a = new boolean[3];

    public static void a(d dVar, int i, int i2) {
        int i3 = i * 2;
        int i4 = i3 + 1;
        c[] cVarArr = dVar.A;
        cVarArr[i3].f237a.f = dVar.D.s.f237a;
        cVarArr[i3].f237a.g = (float) i2;
        cVarArr[i3].f237a.f249b = 1;
        cVarArr[i4].f237a.f = cVarArr[i3].f237a;
        cVarArr[i4].f237a.g = (float) dVar.c(i);
        dVar.A[i4].f237a.f249b = 1;
    }

    /* JADX WARNING: Removed duplicated region for block: B:25:0x0039 A[RETURN] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static boolean a(a.e.a.h.d r4, int r5) {
        /*
            a.e.a.h.d$a[] r0 = r4.C
            r1 = r0[r5]
            a.e.a.h.d$a r2 = a.e.a.h.d.a.MATCH_CONSTRAINT
            r3 = 0
            if (r1 == r2) goto L_0x000a
            return r3
        L_0x000a:
            float r1 = r4.G
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            r2 = 1
            if (r1 == 0) goto L_0x001b
            if (r5 != 0) goto L_0x0015
            goto L_0x0016
        L_0x0015:
            r2 = r3
        L_0x0016:
            r4 = r0[r2]
            a.e.a.h.d$a r5 = a.e.a.h.d.a.MATCH_CONSTRAINT
            return r3
        L_0x001b:
            if (r5 != 0) goto L_0x002b
            int r5 = r4.e
            if (r5 == 0) goto L_0x0022
            return r3
        L_0x0022:
            int r5 = r4.h
            if (r5 != 0) goto L_0x002a
            int r4 = r4.i
            if (r4 == 0) goto L_0x0039
        L_0x002a:
            return r3
        L_0x002b:
            int r5 = r4.f
            if (r5 == 0) goto L_0x0030
            return r3
        L_0x0030:
            int r5 = r4.k
            if (r5 != 0) goto L_0x003a
            int r4 = r4.l
            if (r4 == 0) goto L_0x0039
            goto L_0x003a
        L_0x0039:
            return r2
        L_0x003a:
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: a.e.a.h.i.a(a.e.a.h.d, int):boolean");
    }
}
